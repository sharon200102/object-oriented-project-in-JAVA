
/**
 
 *
 * @author Sharon Komissarov
 */
public class PointNode
{
    
    private Point _point;//the value
    private PointNode _next;//the next PointNode
    
    
    
    

    /**
     * Constructor for objects of class PointNode
     *  @param p a  simpale point 
     *  time complexity O(1)
     * place complexity O(1) 
     */
    public PointNode(Point p)
    {
       this._point=new Point(p);//copy of p
      this._next=null;
    }
    /**
     * Constructor for objects of class PointNode
     * * @param p a  simpale point 
     * @param n is the next PointNode in the list
     *  time complexity O(1)
     * place complexity O(1)
     */
    public PointNode(Point p,PointNode n)
    {
        this._point=new Point(p);//copy of p
        this._next=n;
    }
    /**
     * Constructor for objects of class PointNode
     *  @param p a  simpale PointNode 
     *   time complexity O(1)
     * place complexity O(1)
     */
     public PointNode(PointNode p)
     {
          this._point=new Point(p._point);//copy of p
        this._next=p._next;
     }
     

    /**
  
     *
     * 
     * @return the point of the PointNode 
     *  time complexity O(1)
     * place complexity O(1)
     */
    public Point getPoint()
    
    {
       return  new Point(this._point);//copy of _point
       
    }
    /**
  
     *
     * 
     * @return the next PointNode in the list
     *  time complexity O(1)
     * place complexity O(1)
     */
     public PointNode getNext()
    
    {
       return this._next;
       
    }
    /**
  
     *
     * set a copy of p into _point
     * @param p simpale point
     *  time complexity O(1)
     * place complexity O(1)
     */
    public void  setPoint(Point p)
    {
        this._point=new Point(p);//sets a copy of p
    }
     /**
  
     *
     * set next  into _next
     * @param next simpale PointNode
     *  time complexity O(1)
     * place complexity O(1)
     */
    public void  setNext(PointNode next)
    {
        this._next= next;
    }
    
    
}
