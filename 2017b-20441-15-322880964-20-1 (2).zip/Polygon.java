
/**
 *
 * @author Sharon Komissarov
 */

public class Polygon
{
    
    private PointNode head;//the head of the list
    

    /**
     * Constructor for objects of class Polygon
     *  time complexity O(1)
     * place complexity O(1)
     */
    public Polygon()
    {
        
        head=null;
    }
     /**
     * function that returns the number of vertices in the polygon
     * @return the number of vertices in the polygon
     * time complexity O(n)
     * place complexity O(1)
     */
    private int getLength()
    {
        PointNode pos=this.head;//pointer of the list
        int counter=0;//counts the length
        while(pos!=null)
        {
            counter++;
            pos=pos.getNext();
        }
        return counter;
        
    }


    /**
     * Adding a vertex to the Polygon
     * @param p is the point that we want to add to the polygon
     * @param pos is the the place that we want to add the point
     * @return true if the point was added sucsesfully
     *  time complexity O(n)
     * place complexity O(1)
     */
    public boolean addVertex(Point p, int pos)
    {
      if(pos<1)// if there isn't a polygon at all
      return false;
      if(pos>this.getLength()+1)// if pos is even bigger than the polygon's length and one more
      return false;
      if(pos==1)// if we need to add the head of the list
      {
          
          if(this.head!=null)
         {
          PointNode first=new PointNode(p);
          first.setNext(this.head.getNext());
          this.head.setNext(null);
        }
        else
        {
            this.head=new PointNode(p);
        }
          return true;
      }
      PointNode tmp=this.head;
      PointNode after=this.head.getNext();
      PointNode copy =new PointNode(p);
      while(after!=null)//adding the vertex to the right place
      {
          if(pos==0)
          {
              copy.setNext(after.getNext());
              tmp.setNext(copy);
              after.setNext(null);
              return true;
              
              
          }
          pos--;
          tmp=tmp.getNext();
          after=after.getNext();
          
          
      }
      tmp.setNext(copy);
      return true;
      
    }
    /**
     * The method finds the highest vertex and returns it,if there are more then one returns the first one
     * @return the highest point in the polygon
     * time complexity O(n)
     * place complexity O(n), every call to getPoint method creats an object
     */
    public Point highestVertex()
    {
        if(this.head==null)//if there isn't a polygon at all
        return null;
        PointNode first=this.head;
        double biggestY=this.head.getPoint().getY();
        while(first!=null)//finds the highest vertex
        {
            if (first.getPoint().getY()>biggestY)
            {
             biggestY=first.getPoint().getY(); 
            }
            first=first.getNext();
        }
        first=this.head;
         while(first!=null)//returns the first one
        {
            if (first.getPoint().getY()==biggestY)
            {
             return first.getPoint(); 
            }
            first=first.getNext();
        }
        return null;
        
        
    }
    /**
     * The method returns a string that discriabes the polygon
     * @return string that discriabes the polygon
     *  time complexity O(n)
     * place complexity O(n) every call to getPoint method creats an object
     */
    public String toString()
    {
        String str="(";
        if(this.head==null)//if there isn't a polygon at all
        return "The polyagon has 0 vertices";
        PointNode first=this.head;
        while(first!=null)
        {
        if(first.getNext()!=null)//if this is the last vertex in the list
        {
            str=str+first.getPoint().toString()+",";//string for the last vertex in the list
        }
        else
        {
             str=str+first.getPoint().toString()+")";//sttring for a regular vertex in the list
        }
        first=first.getNext();
        }
        str="The polygon has " +this.getLength()+" vertices:"+"\n"+str;
        return str;
        
        
    }
     /**
     * The method returns the perimeter of the polygon
     * @return the perimeter of the object
     *  time complexity O(n)
     * place complexity O(n) every call to getPoint method creats an object
     */
    public double calcPerimeter()
    {
        if(this.getLength()<=1)//if there isn't a polygon at all
        return 0;
        if(this.getLength()==2)// if the polygon is a line
        return this.head.getPoint().distance(this.head.getNext().getPoint());
        double sum=0;
        PointNode first=this.head;
        while(first.getNext()!=null)
        {
            sum=sum+first.getPoint().distance(first.getNext().getPoint());
            first=first.getNext();
        }
        sum=sum+first.getPoint().distance(this.head.getPoint());
        return sum;

    }
    /**
     * The method returns the area of the triangle that was inserted
     * @param a a side of the triangle
     * @param b a side of the triangle
     * @param c a side of the triangle
     * @param s half of the perimeter of the triangle
     * @return the area of the triangle
     *  time complexity O(1)
     * place complexity O(1) 
     */
    
    private double calcAreaOfTriangle(double a,double b,double c,double s)
         {
         return Math.sqrt(s*(s-a)*(s-b)*(s-c));// Heron formula
        }
        /**
     * The method returns the area of the polygon
     * @return the area of the object
     *  time complexity O(n)
     * place complexity O(n) every call to getPoint method creats an object
     */
        public double calcArea()
        {
            double sum=0,s=0;
            if(this.getLength()<3)//if the polygon is a line or less
            return 0;
            PointNode first=this.head.getNext().getNext();
            PointNode second=this.head.getNext();
            while(first!=null)
            {
                s=(this.head.getPoint().distance(first.getPoint())+this.head.getPoint().distance(second.getPoint())+first.getPoint().distance(second.getPoint()))/2;//the perimeter
                sum=sum+ calcAreaOfTriangle(this.head.getPoint().distance(first.getPoint()),this.head.getPoint().distance(second.getPoint()),first.getPoint().distance(second.getPoint()),s);
                first=first.getNext();
                second=second.getNext();
            }
            return sum;
        }
        /**
     * The method returns true if the area of the polygon is bigger than the area of other
     * @param other a  simpale polygon 
     * @return true if the area of this is bigger than the area of p false if else
     *  time complexity O(n) uses the method calcArea
     * place complexity O(n) uses the method calcArea
     */
        public boolean isBigger(Polygon other)
        {
             if(this.calcArea()>other.calcArea())
            return true;
            return false;
            
        }
        /**
     * The method returns the index of the point in the list, if the point is not in the list the method will return -1
     * @param p a  simpale point 
     * @return the index of the point in the list
     * time complexity O(n)
     * place complexity O(n) every call to getPoint method creats an object
     */
        public int findVertex(Point p)
        {
             PointNode first=this.head;//the pointer of the list
             int counter=1;
             while(first!=null)
             {
                 if(first.getPoint().equals(p))//if found
                 return counter;
                 counter++;
                 first=first.getNext();
             }
             return -1;//if not found
        }
         /**
     * The method returns the point after the point that was inserted
     * @param p a  simpale point 
     * @ return the next point
     * time complexity O(n)
     * place complexity O(1) 
     */
        public Point getNextVertex(Point p)
        {
            if(this.findVertex(p)==-1)//if the point is not in the list
            return null;
            if(this.findVertex(p)==this.getLength())// if the the point is in the end of the list
            return this.head.getPoint();
            PointNode first=this.head;
            int counter=1;
            while(counter!=this.findVertex(p)+1)//finds the next point
            {
                first=first.getNext();
                counter++;
            }
            return  first.getPoint();

             
       
        
        
        }
        /**
     * The method returns a rectangle that blockes the polygon 
     * @ return a rectangle
     * time complexity O(n)
     * place complexity O(n) every call to getPoint method creats an object
     */
         public Polygon getBoundingBox()
         {
            
            double biggestLeft=1000000000,biggestUp=-1,biggestDown=100000000,biggestRight=-1;
             if (this.getLength()<3)
             {
                
                 return null;
             }
             PointNode first=this.head;
             while(first!=null)// finds the min and the max in every angle of the polygon
            
            {
            if(first.getPoint().getX()>biggestRight)
            {
                biggestRight=first.getPoint().getX();
            }
            if(first.getPoint().getX()<biggestLeft)
            {
                biggestLeft=first.getPoint().getX();
            }
            if(first.getPoint().getY()<biggestDown)
            {
                biggestDown=first.getPoint().getY();
            }
            if(first.getPoint().getY()>biggestUp)
            {
                biggestUp=first.getPoint().getY();
            }
        }
        // builds the polygon
        Polygon polygon = new Polygon();
        polygon.addVertex(new Point(biggestLeft,biggestDown),1);
        polygon.addVertex(new Point(biggestRight,biggestDown),2);
        polygon.addVertex(new Point(biggestRight,biggestUp),3);
        polygon.addVertex(new Point(biggestLeft,biggestUp),4);
        return polygon;
            
            
         }
        
    
    
}
